/**
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
*/

/**
 * Define Global Variables
*/
const Sections = document.querySelectorAll('section')
const navList = document.getElementById('navbar_list');
/**
 * End Global Variables
 * 
 * Start Helper Functions
*/

// Activ Link when Active Section
function activeItem(active_section) {
    let navItems = document.querySelectorAll('a')

    navItems.forEach((Item) => {
        if (active_section.getAttribute('data-nav') == Item.textContent) {
            Item.classList.add('activeItem');
        } else {
            Item.classList.remove('activeItem')
        }
    })
}


/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
const fragment = document.createDocumentFragment();

Sections.forEach( (section) => {
    let getAttr = section.getAttribute("data-nav");
    let content = document.createTextNode(getAttr);
    
    let navItem = document.createElement('li');
    let navLink = document.createElement('a');
    
    
    navItem.appendChild(navLink)
    navLink.appendChild(content)
    navLink.classList.add('menu_link');
    navLink.href = "#";
    
    fragment.appendChild(navItem)
    
    // Scroll to section on link click
    navLink.addEventListener('click', function (e) {
        e.preventDefault();

        section.scrollIntoView({
            behavior: 'smooth'
        })
    })
    
    // Add class 'active' to section when near top of viewport
    document.addEventListener('scroll', function () {
        let rect = section.getBoundingClientRect();
        if (rect.top >= 0 && rect.bottom < window.innerHeight) {
            section.classList.add('active_sec');
            activeItem(section)
        } else if (section.classList.contains('active_sec')) {
            section.classList.remove('active_sec')
        }
    })

})
navList.appendChild(fragment);

/**
 * End Main Functions
*/